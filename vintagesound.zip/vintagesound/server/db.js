// Используем sqlite3 — не требует компилятора C++ на Windows
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const dataDir = path.join(__dirname, '../data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbPath = path.join(dataDir, 'vintagesound.db');
const _db = new sqlite3.Database(dbPath);

// Синхронный враппер через промисы + синхронный стиль через better-sqlite3-совместимый API
// Мы используем Database.serialize() и заворачиваем в удобный синхронный интерфейс

// Инициализация таблиц
_db.serialize(() => {
  _db.run('PRAGMA foreign_keys = ON');
  _db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
  _db.run(`CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    price INTEGER NOT NULL,
    category TEXT NOT NULL,
    condition TEXT,
    image TEXT,
    external_url TEXT,
    in_stock INTEGER DEFAULT 1
  )`);
  _db.run(`CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE(product_id, user_id)
  )`);
  _db.run(`CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    total_price INTEGER NOT NULL,
    delivery_address TEXT NOT NULL,
    phone TEXT NOT NULL,
    comment TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  )`);
  _db.run(`CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    price INTEGER NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
  )`);
  _db.run(`CREATE TABLE IF NOT EXISTS contact_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Seed products
  _db.get('SELECT COUNT(*) as cnt FROM products', (err, row) => {
    if (err || row.cnt > 0) return;
    const stmt = _db.prepare(`INSERT INTO products (name,description,price,category,condition,image,external_url) VALUES (?,?,?,?,?,?,?)`);
    [
      ['Fender American Jazzmaster','Классическая американская электрогитара с уникальным тремоло-бриджем и богатым чистым звуком. Кейс в комплекте.',155000,'guitar','Очень хорошее','guitar-1.jpg','https://loud-lemon.com/guitars/fender-american-performer-jazzmaster-vintage-white-2018-usa-elektrogitara'],
      ['Gibson SG Standard','Легендарная гитара с двойными хамбакерами и мощным звуком. Американское производство, кейс в комплекте.',185000,'guitar','Хорошее','guitar-2.jpg','https://loud-lemon.com/guitars/gibson-sg-standard-61-vintage-cherry-2022-usa-elektrogitara-8707'],
      ['Rickenbacker 330','Культовая гитара Beatles и The Byrds. Уникальное звучание, отличное состояние.',175000,'guitar','Отличное','guitar-3.jpg','https://loud-lemon.com/guitars/rickenbacker-330-jetglo-2007-usa-elektrogitara'],
      ['Fender Stratocaster','Классическая Stratocaster — три сингла, комфортный гриф, универсальный инструмент для любого стиля.',37500,'guitar','Отличное','guitar-4.jpg',null],
      ['65AMPS Colour Boost','Винтажный овердрайв педаль американского производства. Прозрачный, музыкальный буст.',30000,'pedal','Хорошее','pedal-1.jpg','https://loud-lemon.com/effects/65amps-colour-boost-overdrayv'],
      ['Fender Super Sonic 22 Head','Ламповый усилитель мощностью 22 Вт с двумя каналами: Vintage и Burn.',207000,'amp','Хорошее','amp-1.jpg',null],
      ['Superlux CMH8D','Студийный ламповый микрофон с большой диафрагмой. Тёплый, детальный звук.',19000,'studio','Отличное','mic-1.jpg',null],
    ].forEach(p => stmt.run(...p));
    stmt.finalize();
    console.log('✔ База данных заполнена тестовыми товарами');
  });
});

// Промис-обёртки для удобного использования в роутах
const db = {
  // Получить все строки
  all(sql, params = []) {
    return new Promise((resolve, reject) => {
      _db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows || []));
    });
  },
  // Получить одну строку
  get(sql, params = []) {
    return new Promise((resolve, reject) => {
      _db.get(sql, params, (err, row) => err ? reject(err) : resolve(row || null));
    });
  },
  // Выполнить запрос (INSERT/UPDATE/DELETE)
  run(sql, params = []) {
    return new Promise((resolve, reject) => {
      _db.run(sql, params, function(err) {
        if (err) reject(err);
        else resolve({ lastInsertRowid: this.lastID, changes: this.changes });
      });
    });
  },
};

module.exports = db;
