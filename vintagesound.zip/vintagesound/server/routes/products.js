const router = require('express').Router();
const db = require('../db');

router.get('/', async (req, res) => {
  const { category, sort, search } = req.query;
  let query = 'SELECT * FROM products WHERE 1=1';
  const params = [];
  if (category && category !== 'all') { query += ' AND category = ?'; params.push(category); }
  if (search) { query += ' AND name LIKE ?'; params.push(`%${search}%`); }
  if (sort === 'asc') query += ' ORDER BY price ASC';
  else if (sort === 'desc') query += ' ORDER BY price DESC';
  res.json(await db.all(query, params));
});

router.get('/:id', async (req, res) => {
  const product = await db.get('SELECT * FROM products WHERE id = ?', [req.params.id]);
  if (!product) return res.status(404).json({ error: 'Not found' });
  res.json(product);
});

module.exports = router;
