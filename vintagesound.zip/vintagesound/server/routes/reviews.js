const router = require('express').Router();
const { body, validationResult } = require('express-validator');
const db = require('../db');

router.post('/', [
  body('product_id').isInt({min:1}),
  body('rating').isInt({min:1,max:5}).withMessage('Оценка от 1 до 5'),
  body('comment').trim().isLength({min:5,max:500}).withMessage('Отзыв: от 5 до 500 символов'),
], async (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'Войдите в систему' });
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { product_id, rating, comment } = req.body;
  try {
    await db.run('INSERT INTO reviews (product_id,user_id,rating,comment) VALUES (?,?,?,?)',
      [parseInt(product_id), req.session.user.id, parseInt(rating), comment]);
    res.json({ success: true });
  } catch(e) {
    res.status(400).json({ error: 'Вы уже оставили отзыв на этот товар' });
  }
});

module.exports = router;
