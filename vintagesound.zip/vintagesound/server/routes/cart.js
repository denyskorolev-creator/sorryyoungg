const router = require('express').Router();
const db = require('../db');

router.post('/add', async (req, res) => {
  const { product_id, quantity = 1 } = req.body;
  const product = await db.get('SELECT id FROM products WHERE id = ?', [parseInt(product_id)]);
  if (!product) return res.status(404).json({ error: 'Товар не найден' });
  if (!req.session.cart) req.session.cart = [];
  const existing = req.session.cart.find(i => i.id === product.id);
  if (existing) existing.quantity += parseInt(quantity);
  else req.session.cart.push({ id: product.id, quantity: parseInt(quantity) });
  const totalItems = req.session.cart.reduce((s, i) => s + i.quantity, 0);
  res.json({ success: true, cartCount: totalItems });
});

router.post('/remove', (req, res) => {
  const { product_id } = req.body;
  req.session.cart = (req.session.cart || []).filter(i => i.id !== parseInt(product_id));
  res.redirect('/cart');
});

router.post('/update', (req, res) => {
  const { product_id, quantity } = req.body;
  const qty = parseInt(quantity);
  if (!req.session.cart) return res.redirect('/cart');
  if (qty <= 0) req.session.cart = req.session.cart.filter(i => i.id !== parseInt(product_id));
  else { const item = req.session.cart.find(i => i.id === parseInt(product_id)); if (item) item.quantity = qty; }
  res.redirect('/cart');
});

router.get('/count', (req, res) => {
  const count = (req.session.cart || []).reduce((s, i) => s + i.quantity, 0);
  res.json({ count });
});

module.exports = router;
