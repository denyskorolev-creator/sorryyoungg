const router = require('express').Router();
const { body, validationResult } = require('express-validator');
const db = require('../db');

router.post('/', [
  body('name').trim().isLength({min:2,max:100}).withMessage('Имя: от 2 до 100 символов'),
  body('email').isEmail().withMessage('Введите корректный email'),
  body('phone').optional({checkFalsy:true}).matches(/^[\d\s\+\-\(\)]{7,20}$/).withMessage('Некорректный формат телефона'),
  body('subject').trim().isLength({min:3,max:200}).withMessage('Тема: от 3 до 200 символов'),
  body('message').trim().isLength({min:10,max:2000}).withMessage('Сообщение: от 10 до 2000 символов'),
], async (req, res) => {
  const errors = validationResult(req);
  const { name, email, phone, subject, message } = req.body;
  if (!errors.isEmpty()) return res.render('contact', { page:'contact', success:false, errors:errors.array(), values:{name,email,phone,subject,message} });
  await db.run('INSERT INTO contact_messages (name,email,phone,subject,message) VALUES (?,?,?,?,?)',
    [name, email, phone||null, subject, message]);
  res.render('contact', { page:'contact', success:true, errors:[], values:{} });
});

module.exports = router;
