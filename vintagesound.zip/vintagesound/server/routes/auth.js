const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const db = require('../db');

router.get('/login', (req, res) => {
  if (req.session.user) return res.redirect('/');
  res.render('login', { page: 'login', errors: [], values: {}, redirect: req.query.redirect || '/' });
});

router.post('/login', [
  body('email').isEmail().withMessage('Введите корректный email'),
  body('password').notEmpty().withMessage('Введите пароль'),
], async (req, res) => {
  const errors = validationResult(req);
  const { email, password, redirect = '/' } = req.body;
  if (!errors.isEmpty()) return res.render('login', { page:'login', errors:errors.array(), values:{email}, redirect });

  const user = await db.get('SELECT * FROM users WHERE email = ?', [email]);
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.render('login', { page:'login', errors:[{msg:'Неверный email или пароль'}], values:{email}, redirect });
  }
  req.session.user = { id: user.id, username: user.username, email: user.email };
  res.redirect(redirect);
});

router.get('/register', (req, res) => {
  if (req.session.user) return res.redirect('/');
  res.render('register', { page: 'register', errors: [], values: {} });
});

router.post('/register', [
  body('username').trim().isLength({min:3,max:20}).withMessage('Имя: от 3 до 20 символов')
    .matches(/^[a-zA-Zа-яА-ЯёЁ0-9_]+$/).withMessage('Только буквы, цифры и _'),
  body('email').isEmail().withMessage('Введите корректный email').normalizeEmail(),
  body('password').isLength({min:6}).withMessage('Пароль: минимум 6 символов')
    .matches(/[0-9]/).withMessage('Пароль должен содержать хотя бы одну цифру'),
  body('password_confirm').custom((v, {req}) => {
    if (v !== req.body.password) throw new Error('Пароли не совпадают');
    return true;
  }),
], async (req, res) => {
  const errors = validationResult(req);
  const { username, email, password } = req.body;
  if (!errors.isEmpty()) return res.render('register', { page:'register', errors:errors.array(), values:{username,email} });

  const existing = await db.get('SELECT id FROM users WHERE email = ? OR username = ?', [email, username]);
  if (existing) return res.render('register', { page:'register', errors:[{msg:'Пользователь с таким email или именем уже существует'}], values:{username,email} });

  const hash = bcrypt.hashSync(password, 10);
  const result = await db.run('INSERT INTO users (username,email,password) VALUES (?,?,?)', [username, email, hash]);
  req.session.user = { id: result.lastInsertRowid, username, email };
  res.redirect('/?welcome=1');
});

router.post('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

module.exports = router;
