const express = require('express');
const session = require('express-session');
const path = require('path');
const db = require('./db');

const authRoutes = require('./routes/auth');
const cartRoutes = require('./routes/cart');
const productRoutes = require('./routes/products');
const reviewRoutes = require('./routes/reviews');
const contactRoutes = require('./routes/contact');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Сессии — храним в памяти (без SQLite, чтобы не нужен был connect-sqlite3)
app.use(session({
  secret: 'vintagesound-secret-key-2025',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 7 * 24 * 60 * 60 * 1000 }
}));

app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  next();
});

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

app.use('/auth', authRoutes);
app.use('/cart', cartRoutes);
app.use('/api/products', productRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/contact', contactRoutes);

app.get('/', async (req, res) => {
  const products = await db.all('SELECT * FROM products ORDER BY RANDOM() LIMIT 3');
  res.render('index', { products, page: 'home', query: req.query });
});

app.get('/catalog', async (req, res) => {
  const { category, sort, search, min_price, max_price } = req.query;
  let query = 'SELECT * FROM products WHERE 1=1';
  const params = [];
  if (category && category !== 'all') { query += ' AND category = ?'; params.push(category); }
  if (search) { query += ' AND (name LIKE ? OR description LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
  if (min_price) { query += ' AND price >= ?'; params.push(parseInt(min_price)); }
  if (max_price) { query += ' AND price <= ?'; params.push(parseInt(max_price)); }
  if (sort === 'asc') query += ' ORDER BY price ASC';
  else if (sort === 'desc') query += ' ORDER BY price DESC';
  else if (sort === 'name') query += ' ORDER BY name ASC';
  else query += ' ORDER BY id ASC';
  const products = await db.all(query, params);
  res.render('catalog', { products, page: 'catalog', query: req.query });
});

app.get('/about', (req, res) => res.render('about', { page: 'about' }));

app.get('/product/:id', async (req, res) => {
  const product = await db.get('SELECT * FROM products WHERE id = ?', [req.params.id]);
  if (!product) return res.status(404).render('404', { page: '' });
  const reviews = await db.all(
    `SELECT r.*, u.username FROM reviews r JOIN users u ON r.user_id = u.id WHERE r.product_id = ? ORDER BY r.created_at DESC`,
    [req.params.id]
  );
  const avgRating = reviews.length ? (reviews.reduce((s,r) => s+r.rating, 0) / reviews.length).toFixed(1) : null;
  res.render('product', { product, reviews, avgRating, page: 'catalog' });
});

app.get('/profile', requireAuth, async (req, res) => {
  const user = await db.get('SELECT id,username,email,created_at FROM users WHERE id = ?', [req.session.user.id]);
  const orders = await db.all(
    `SELECT o.*, GROUP_CONCAT(p.name || ' x' || oi.quantity, ', ') as items_list
     FROM orders o
     JOIN order_items oi ON o.id = oi.order_id
     JOIN products p ON oi.product_id = p.id
     WHERE o.user_id = ? GROUP BY o.id ORDER BY o.created_at DESC`,
    [user.id]
  );
  res.render('profile', { user, orders, page: 'profile', query: req.query });
});

app.get('/cart', async (req, res) => {
  const cartItems = req.session.cart || [];
  let products = [];
  if (cartItems.length > 0) {
    const ids = cartItems.map(i => i.id);
    const placeholders = ids.map(() => '?').join(',');
    const prods = await db.all(`SELECT * FROM products WHERE id IN (${placeholders})`, ids);
    products = cartItems.map(item => {
      const prod = prods.find(p => p.id === item.id);
      return prod ? { ...prod, quantity: item.quantity } : null;
    }).filter(Boolean);
  }
  const total = products.reduce((s, p) => s + p.price * p.quantity, 0);
  res.render('cart', { products, total, page: 'cart' });
});

app.get('/checkout', requireAuth, async (req, res) => {
  const cartItems = req.session.cart || [];
  if (!cartItems.length) return res.redirect('/cart');
  const ids = cartItems.map(i => i.id);
  const prods = await db.all(`SELECT * FROM products WHERE id IN (${ids.map(()=>'?').join(',')})`, ids);
  const products = cartItems.map(item => { const p = prods.find(p=>p.id===item.id); return p ? {...p, quantity:item.quantity} : null; }).filter(Boolean);
  const total = products.reduce((s,p) => s+p.price*p.quantity, 0);
  res.render('checkout', { products, total, page: 'checkout' });
});

app.post('/checkout', requireAuth, async (req, res) => {
  const cartItems = req.session.cart || [];
  if (!cartItems.length) return res.redirect('/cart');
  const { delivery_address, phone, comment } = req.body;
  const ids = cartItems.map(i => i.id);
  const prods = await db.all(`SELECT * FROM products WHERE id IN (${ids.map(()=>'?').join(',')})`, ids);
  const total = cartItems.reduce((s, item) => { const p = prods.find(p=>p.id===item.id); return p ? s+p.price*item.quantity : s; }, 0);
  const order = await db.run(
    `INSERT INTO orders (user_id,total_price,delivery_address,phone,comment,status) VALUES (?,?,?,?,?,'pending')`,
    [req.session.user.id, total, delivery_address, phone, comment||'']
  );
  for (const item of cartItems) {
    const p = prods.find(p=>p.id===item.id);
    if (p) await db.run('INSERT INTO order_items (order_id,product_id,quantity,price) VALUES (?,?,?,?)',
      [order.lastInsertRowid, item.id, item.quantity, p.price]);
  }
  req.session.cart = [];
  res.redirect('/profile?order=success');
});

app.get('/contact', (req, res) => res.render('contact', { page:'contact', success:false, errors:[], values:{} }));

app.use((req, res) => res.status(404).render('404', { page: '' }));

function requireAuth(req, res, next) {
  if (!req.session.user) return res.redirect('/auth/login?redirect=' + encodeURIComponent(req.originalUrl));
  next();
}

app.listen(PORT, () => console.log(`VintageSoundNN запущен на http://localhost:${PORT}`));
