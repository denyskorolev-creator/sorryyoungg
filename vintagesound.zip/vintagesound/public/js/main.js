document.addEventListener('DOMContentLoaded', function () {

  /* === 1. Тема === */
  const themeToggle = document.getElementById('themeToggle');
  const savedTheme = localStorage.getItem('theme') || 'dark';
  document.body.classList.remove('theme-dark', 'theme-light');
  document.body.classList.add('theme-' + savedTheme);
  if (themeToggle) themeToggle.textContent = savedTheme === 'dark' ? '☀' : '🌙';

  if (themeToggle) {
    themeToggle.addEventListener('click', function () {
      const isDark = document.body.classList.contains('theme-dark');
      document.body.classList.toggle('theme-dark', !isDark);
      document.body.classList.toggle('theme-light', isDark);
      localStorage.setItem('theme', isDark ? 'light' : 'dark');
      themeToggle.textContent = isDark ? '🌙' : '☀';
    });
  }

  /* === 2. Счётчик корзины === */
  function updateCartCount() {
    fetch('/cart/count')
      .then(r => r.json())
      .then(data => {
        const el = document.getElementById('cartCount');
        if (el) {
          el.textContent = data.count;
          el.style.display = data.count > 0 ? '' : 'none';
        }
      })
      .catch(() => {});
  }
  updateCartCount();

  /* === 3. Добавление в корзину === */
  document.querySelectorAll('.add-to-cart-btn').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();

      const productId = btn.getAttribute('data-id');
      const productName = btn.getAttribute('data-name') || 'Товар';

      fetch('/cart/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'product_id=' + encodeURIComponent(productId) + '&quantity=1'
      })
        .then(r => r.json())
        .then(data => {
          if (data.success) {
            const el = document.getElementById('cartCount');
            if (el) {
              el.textContent = data.cartCount;
              el.style.display = '';
            }
            showToast('«' + productName + '» добавлен в корзину 🛒');

            // Анимация кнопки
            const orig = btn.textContent;
            btn.textContent = '✓ Добавлено';
            btn.style.background = '#38a169';
            setTimeout(() => {
              btn.textContent = orig;
              btn.style.background = '';
            }, 1500);
          }
        })
        .catch(() => showToast('Ошибка. Попробуйте снова.'));
    });
  });

  /* === 4. Toast уведомление === */
  function showToast(message) {
    let toast = document.getElementById('toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'toast';
      toast.style.cssText = `
        position: fixed; bottom: 24px; right: 24px; z-index: 9999;
        background: #232323; color: #f5f5f5; border: 1px solid #ff7a00;
        padding: 12px 20px; border-radius: 6px; font-size: 14px;
        box-shadow: 0 4px 14px rgba(0,0,0,0.4);
        transform: translateY(20px); opacity: 0;
        transition: all 0.25s ease;
        max-width: 300px;
      `;
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    requestAnimationFrame(() => {
      toast.style.transform = 'translateY(0)';
      toast.style.opacity = '1';
    });
    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => {
      toast.style.transform = 'translateY(20px)';
      toast.style.opacity = '0';
    }, 3000);
  }

  /* === 5. Анимация карточек при скролле === */
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.product-card, .category-card, .feature-card').forEach(card => {
      card.style.opacity = '0';
      card.style.transform = 'translateY(16px)';
      card.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
      observer.observe(card);
    });
  }

  /* === 6. Мобильное меню (если надо) === */
  const hamburger = document.getElementById('hamburger');
  const mobileNav = document.querySelector('.main-nav');
  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => {
      mobileNav.classList.toggle('nav-open');
    });
  }

});
